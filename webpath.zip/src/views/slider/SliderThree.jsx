import React from 'react';
import SliderPortfolio from "../../components/slider-portfolio/SliderPortfolio";

function SliderThree() {
    return (
        <SliderPortfolio tag="header"/>
    );
}

export default SliderThree;