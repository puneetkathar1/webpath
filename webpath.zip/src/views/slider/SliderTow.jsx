import React from 'react';
import SliderPortfolio from "../../components/slider-portfolio/SliderPortfolio";

function SliderTow() {
    return (
        <SliderPortfolio tag="header" typeBg="padding-image"/>
    );
}

export default SliderTow;