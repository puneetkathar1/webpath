import React from 'react';
import SliderPortfolio from "../../components/slider-portfolio/SliderPortfolio";

function SliderOne() {
    return (
        <SliderPortfolio tag="header" typeBg="full-image"/>
    );
}

export default SliderOne;